/*
 * Fimex
 *
 * (C) Copyright 2008, met.no
 *
 * Project Info:  https://wiki.met.no/fimex/start
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 */

#ifndef CDMATTRIBUTE_H_
#define CDMATTRIBUTE_H_

#include <string>
#include <vector>
#include <iosfwd>
#include <boost/shared_ptr.hpp>
#include "fimex/DataDecl.h"
#include "fimex/CDMDataType.h"
#include "fimex/CDMNamedEntity.h"
#include "fimex/CDMException.h"
#include "fimex/deprecated.h"

namespace MetNoFimex
{

/**
 * @headerfile fimex/CDMAttribute.h
 */
class CDMAttribute : public CDMNamedEntity
{

public:
    CDMAttribute();
    /// create a string attribute
    explicit CDMAttribute(std::string name, std::string value);
    /// create a char attribute with a char array of length 1
    explicit CDMAttribute(std::string name, char value);
    /// create a int attribute with a int array of length 1
    explicit CDMAttribute(std::string name, int value);
    /// create a short attribute with a short array of length 1
    explicit CDMAttribute(std::string name, short value);
    /// create a float attribute with a float array of length 1
    explicit CDMAttribute(std::string name, float value);
    /// create a double attribute with a double array of length 1
    explicit CDMAttribute(std::string name, double value);
    /// create a attribute with the low level information
    explicit CDMAttribute(std::string name, CDMDataType datatype, DataPtr data);
    /// create a attribute from a string representation
    explicit CDMAttribute(const std::string& name, const std::string& datatype, const std::string& value);
    /// create a attribute with a vector of values in string representation
    explicit CDMAttribute(const std::string& name, CDMDataType datatype, const std::vector<std::string>& values);
    virtual ~CDMAttribute();
    /// retrieve the name of the attribute
    const std::string& getName() const {return name;}
    /// set the name of the attribute
    void setName(std::string newName) {name = newName;}
    /// retrieve the stringified value of the attribute
    const std::string getStringValue() const;
    /// retrieve the data-pointer of the attribute
    const DataPtr getData() const {return data;}
    /// set the data for this attribute
    void setData(DataPtr data) {this->data = data;}
    /// retrieve the datatype of the attribute
    CDMDataType getDataType() const {return datatype;}
    void toXMLStream(std::ostream& out, const std::string& indent = "") const;
private:
    std::string name;
    CDMDataType datatype;
    DataPtr data;
    /* datatype and name must be set to call this init function */
    void initDataByArray(const std::vector<std::string>& values);
    /* init data arrays for all types */
    template<typename T>
    void initDataArray(const std::vector<std::string>& values);
};

/**
 * @brief convert a proj4 string to a list of CDMAttributes usable for CF-1.0 projection variable
 *
 * currently, projStrings of the form +proj=[stere] +lat_0=? +lon_0=? +lat_ts=?
 * @deprecated use Projection::createByProj4() and Projection::getParameters()
 */
MIFI_DEPRECATED(std::vector<CDMAttribute> projStringToAttributes(std::string projStr));
/**
 * @brief convert attributes of a projection-variable to a projString
 *
 * @deprecated use Projection::create() with Projection::getProj4String() instead
 * @param attrs attributes of the projection variable
 * @return proj4 string
 */
MIFI_DEPRECATED(std::string attributesToProjString(const std::vector<CDMAttribute>& attrs));


}

#endif /*CDMATTRIBUTE_H_*/
