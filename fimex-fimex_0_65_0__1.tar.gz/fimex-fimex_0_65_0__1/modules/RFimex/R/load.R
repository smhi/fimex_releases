".First.lib" <- function(lib, pkg) {
    cacheMetaData(1)
}
